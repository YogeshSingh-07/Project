package com.GLCA.TicketsList.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.GLCA.TicketsList.dao.TicketDao;
import com.GLCA.TicketsList.entity.Ticket;

@Service
public class TicketsService {

	
	
		TicketDao ticketDao;
	
		public TicketsService(TicketDao ticketDao) {
		super();
		this.ticketDao = ticketDao;
		}
	
		public List<Ticket> getList(){
			return ticketDao.findAll();
		}
		
		public void saveTicket(Ticket ticket) {
			ticketDao.save(ticket);
		}
		
		public Ticket updateTicket(int id) {
			return ticketDao.findById(id).get();
			
		}
		
		public void deleteTicket(int id){
			ticketDao.deleteById(id);
		}

		public Ticket viewTicket(int id) {
			return ticketDao.findById(id).get();
		}
		
		public List<Ticket> search(String str){
			return ticketDao.searchByDescriptionAndTitle(str);
		}
	
}

package com.GLCA.TicketsList.controller;


import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.GLCA.TicketsList.entity.Ticket;
import com.GLCA.TicketsList.service.TicketsService;

@Controller
public class TicketController {

	

	TicketsService ticketService;
	
	
	public TicketController(TicketsService ticketService) {
		super();
		this.ticketService = ticketService;
	}


	@RequestMapping("/")
	public String goToWelcomePage(ModelMap model) {
		List<Ticket> ticketlist = ticketService.getList();
		model.addAttribute("ticketlist", ticketlist);
		return"tickets";
	}
	
	@RequestMapping(value="create-ticket", method=RequestMethod.GET)
	public String goToEditPage(ModelMap model) {
		Ticket ticket = new Ticket();
		model.addAttribute("ticket", ticket);
		return "addTicket";
	}
	



	@RequestMapping(value="create-ticket", method=RequestMethod.POST)
	public String createTicket(@ModelAttribute("ticket") Ticket ticket) {
		
		ticket.setDate(LocalDate.now());
		ticketService.saveTicket(ticket);
		return "redirect:/";
	}
	
	
	
	@RequestMapping(value="edit-ticket",method = RequestMethod.GET)
	public String editTicket(@RequestParam int id,ModelMap model) {
		Ticket ticket = ticketService.updateTicket(id);
		model.put("ticket", ticket);
		return "addTicket";
	}
	
	
	
	@RequestMapping(value="edit-ticket",method = RequestMethod.POST)
	public String saveEditedTicket(@ModelAttribute ("ticket") Ticket ticket) {
		ticket.setDate(LocalDate.now());
		ticketService.saveTicket(ticket);
		return"redirect:/";
	}
	
	@RequestMapping("delete-ticket")
	public  String deleteTicket(@RequestParam int id) {
		ticketService.deleteTicket(id);
		return"redirect:/";
	}
	
	
	
	@RequestMapping("view-ticket")
	public  String viewCurrentTicket(@RequestParam int id,ModelMap model) {
		Ticket ticket=ticketService.viewTicket(id);
		model.put("ticket", ticket);
		return"view";
	}
	
	
	
	@RequestMapping("search")
	public String searchTicket(@RequestParam String search,ModelMap model) {
		
		List<Ticket> tickets = ticketService.search(search);
		model.addAttribute("ticketlist", tickets);
		return"tickets";
	}
	
	
}

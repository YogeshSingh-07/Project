package com.GLCA.TicketsList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketsListApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketsListApplication.class, args);
		System.out.println("Working..");
	}

}

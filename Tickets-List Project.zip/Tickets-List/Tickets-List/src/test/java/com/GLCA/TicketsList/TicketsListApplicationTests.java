package com.GLCA.TicketsList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketsListApplicationTests {

	@Test
	void contextLoads() {
	}

}
